package hydracommlayer

func Connect(protocol string){

}