package main

import "Hydra/hydraweb/hydrarestapi"

func main() {

	hydrarestapi.RunAPI()
}
